package Module6;

public interface PatientInfo 
{
	public double BMI(String UsersWeight, String UsersHeight);
}
