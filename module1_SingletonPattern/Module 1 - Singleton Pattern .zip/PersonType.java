package module1_SingletonPattern;

import java.util.Scanner;

public class PersonType {
	
	private static PersonType personType = new PersonType();

	String fName;
	String mName;
	String lName;
	
	public static PersonType getInstance(){
		
		return personType;
	}
	
	public void Name()
	{
		//This creates the scanner object so we can take user input
		Scanner s = new Scanner(System.in);
				
		//Asks user for input
		System.out.println("What is your first name?");
				
		//Waits for user input and assigns it to a String variable (fName)
		String fName = s.nextLine();
		
		//Asks user for input
		System.out.println("What is your last name?");
				
		//Waits for user input and assigns it to a String variable (fName)
		String lName = s.nextLine();
		
		//Asks user for input
		System.out.println("What is your middle name?");
				
		//Waits for user input and assigns it to a String variable (fName)
		String mName = s.nextLine();	
		
		System.out.println("First name " + fName);
		System.out.println("Last name " + lName);
		System.out.println("Middle name " + mName);
		
		//Closing scanner
		s.close();
	}
	
}